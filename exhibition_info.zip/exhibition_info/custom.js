$(function(){
  $('.exhibitions-menu a').click(function(e){
    e.preventDefault();
    $('.exhibitions-menu a').removeClass('active');
    $(this).addClass('active');
  });
});